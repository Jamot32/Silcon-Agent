# Tiny Tapeout integration status

This bundle contains the selected real standalone sky130 flow. Its source and tests are copied from that flow's immutable input snapshot, rather than the latest edited working files.

The info.yaml draft follows the current SKY template (yaml_version 6): https://github.com/TinyTapeout/ttsky-verilog-template/blob/main/info.yaml. Tiny Tapeout requires a unique tt_um_* top and the fixed ui_in/uo_out/uio_in/uio_out/uio_oe/ena/clk/rst_n wrapper. This demo has not generated or verified that wrapper, mapped the 24 digital pins, proven a Tiny Tapeout tile fit, or run shuttle-specific integration checks. Empty pin descriptions and the 1x1 tile choice are draft fields. Add the wrapper and pin mapping, then re-simulate and re-harden using the current SKY template before submission. DRC/LVS results describe this standalone flow and do not establish shuttle readiness.
