import cocotb
from cocotb.triggers import Timer
import random


async def initialize(dut):
    dut.clk.value = 0
    dut.rst_n.value = 0
    dut.enable.value = 0
    dut.load.value = 0
    dut.up.value = 0
    dut.load_data.value = 0
    await Timer(5, unit='ns')
    dut.clk.value = 1
    await Timer(5, unit='ns')
    assert int(dut.count.value) == 0, 'Reset must establish zero'
    dut.clk.value = 0
    await Timer(5, unit='ns')
    return 0


async def cycle(dut, previous, rst_n=1, load=0, enable=0, up=0, data=0):
    dut.rst_n.value = rst_n
    dut.load.value = load
    dut.enable.value = enable
    dut.up.value = up
    dut.load_data.value = data
    await Timer(5, unit='ns')
    assert int(dut.count.value) == previous, 'Inputs changed count before rising edge'
    expected = 0 if not rst_n else data if load else ((previous + (1 if up else -1)) & 255) if enable else previous
    dut.clk.value = 1
    await Timer(5, unit='ns')
    assert int(dut.count.value) == expected, ('Rising edge mismatch', previous, rst_n, load, enable, up, data, expected, int(dut.count.value))
    dut.clk.value = 0
    await Timer(5, unit='ns')
    assert int(dut.count.value) == expected, 'Falling edge changed count'
    return expected


@cocotb.test()
async def synchronous_reset_priority(dut):
    state = await initialize(dut)
    for direction in (0, 1):
        for enabled in (0, 1):
            for loading in (0, 1):
                state = await cycle(dut, state, load=1, data=173)
                state = await cycle(dut, state, rst_n=0, load=loading, enable=enabled, up=direction, data=219)
                state = await cycle(dut, state, rst_n=0, load=loading, enable=enabled, up=direction, data=87)
    state = await cycle(dut, state, enable=1, up=1)


@cocotb.test()
async def load_values_and_priority(dut):
    state = await initialize(dut)
    for data in (0, 1, 127, 128, 255):
        for enabled in (0, 1):
            for direction in (0, 1):
                state = await cycle(dut, state, load=1, enable=enabled, up=direction, data=data)
    for data in range(256):
        state = await cycle(dut, state, load=1, enable=data & 1, up=(data >> 1) & 1, data=data)


@cocotb.test()
async def consecutive_counting(dut):
    state = await initialize(dut)
    state = await cycle(dut, state, load=1, data=120)
    for direction in (1, 0):
        for index in range(80):
            state = await cycle(dut, state, enable=1, up=direction, data=(index * 37) & 255)


@cocotb.test()
async def disabled_hold(dut):
    state = await initialize(dut)
    for value in (0, 1, 85, 170, 255):
        state = await cycle(dut, state, load=1, data=value)
        for index in range(32):
            state = await cycle(dut, state, up=index & 1, data=(index * 19) & 255)


@cocotb.test()
async def wraparound_both_directions(dut):
    state = await initialize(dut)
    state = await cycle(dut, state, load=1, data=255)
    for index in range(258):
        state = await cycle(dut, state, enable=1, up=1)
    state = await cycle(dut, state, load=1, data=0)
    for index in range(258):
        state = await cycle(dut, state, enable=1, up=0)


@cocotb.test()
async def mixed_operations_and_high_phase_inputs(dut):
    state = await initialize(dut)
    rng = random.Random(7139)
    for index in range(400):
        reset = 0 if rng.randrange(8) == 0 else 1
        loading = rng.randrange(2)
        enabled = rng.randrange(2)
        direction = rng.randrange(2)
        data = rng.randrange(256)
        state = await cycle(dut, state, rst_n=reset, load=loading, enable=enabled, up=direction, data=data)
        # Reproduce the same operation at a second rising edge, then
        # change every control during the high phase without a rising edge.
        dut.clk.value = 1
        await Timer(5, unit='ns')
        state = 0 if not reset else data if loading else ((state + (1 if direction else -1)) & 255) if enabled else state
        assert int(dut.count.value) == state
        dut.rst_n.value = 1 - reset
        dut.load.value = 1 - loading
        dut.enable.value = 1 - enabled
        dut.up.value = 1 - direction
        dut.load_data.value = data ^ 255
        await Timer(5, unit='ns')
        assert int(dut.count.value) == state, 'High-phase input change altered count'
        dut.clk.value = 0
        await Timer(5, unit='ns')
        assert int(dut.count.value) == state, 'Falling edge captured changed inputs'
