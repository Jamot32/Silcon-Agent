module up_down_counter (
    input wire clk,
    input wire rst_n,
    input wire enable,
    input wire load,
    input wire up,
    input wire [7:0] load_data,
    output reg [7:0] count
);

    wire [7:0] toggle;
    wire [7:0] stepped;
    assign toggle[0] = enable;
    genvar i;
    generate
        for (i = 1; i < 8; i = i + 1) begin : toggle_chain
            assign toggle[i] = toggle[i-1] & ~(count[i-1] ^ up);
        end
    endgenerate
    assign stepped = count ^ toggle;

    always @(posedge clk) begin
        if (!rst_n) begin
            count <= 8'd0;
        end else if (load) begin
            count <= load_data;
        end else begin
            count <= stepped;
        end
    end

endmodule
