import cocotb
from cocotb.triggers import Timer


async def tick(dut):
    dut.clk.value = 0
    await Timer(5, unit='ns')
    await Timer(5, unit='ns')
    dut.clk.value = 1
    await Timer(5, unit='ns')
    await Timer(5, unit='ns')


def check(dut, busy, tx, label):
    actual = (int(dut.busy.value), int(dut.tx.value))
    assert actual == (busy, tx), f'{label}: expected busy/tx {(busy, tx)}, got {actual}'


async def reset(dut):
    dut.clk.value = 0
    dut.rst_n.value = 0
    dut.send.value = 0
    dut.data.value = 0
    await tick(dut)
    check(dut, 0, 1, 'reset')
    dut.rst_n.value = 1
    await tick(dut)
    check(dut, 0, 1, 'idle after reset')


def frame_bit(payload, age):
    if age < 4:
        return 0
    if age < 36:
        return (payload >> (age // 4 - 1)) & 1
    return 1


async def frame(dut, payload, mutate=False, pulses=False):
    dut.data.value = payload
    dut.send.value = 1
    await tick(dut)
    check(dut, 1, 0, 'acceptance age 0')
    for age in range(1, 41):
        dut.send.value = int(pulses and age in (1, 3, 7, 19, 35, 36, 38, 39, 40))
        if mutate:
            dut.data.value = (payload ^ (age * 73)) & 255
        await tick(dut)
        check(dut, int(age < 40), frame_bit(payload, age), f'payload {payload:02x}, age {age}')
    dut.send.value = 0


@cocotb.test()
async def exact_framing_and_lsb_order(dut):
    await reset(dut)
    for payload in (0x96, 0x69):
        await frame(dut, payload)
        await tick(dut)
        check(dut, 0, 1, 'interframe idle')


@cocotb.test()
async def payload_is_latched(dut):
    await reset(dut)
    await frame(dut, 0x96, mutate=True)
    await frame(dut, 0x69, mutate=True)


@cocotb.test()
async def busy_requests_are_discarded(dut):
    await reset(dut)
    await frame(dut, 0x69, mutate=True, pulses=True)
    for age in range(45):
        await tick(dut)
        check(dut, 0, 1, f'no queued frame idle {age}')


@cocotb.test()
async def held_send_accepts_only_after_completion(dut):
    await reset(dut)
    dut.data.value = 0x96
    dut.send.value = 1
    await tick(dut)
    check(dut, 1, 0, 'first acceptance')
    dut.data.value = 0x69
    for age in range(1, 41):
        await tick(dut)
        check(dut, int(age < 40), frame_bit(0x96, age), f'held send first age {age}')
    await tick(dut)
    check(dut, 1, 0, 'second acceptance at E+41')
    dut.send.value = 0
    dut.data.value = 0
    for age in range(1, 41):
        await tick(dut)
        check(dut, int(age < 40), frame_bit(0x69, age), f'second age {age}')


@cocotb.test()
async def synchronous_reset_priority_and_abort(dut):
    await reset(dut)
    dut.data.value = 0
    dut.send.value = 1
    await tick(dut)
    check(dut, 1, 0, 'start before reset')
    dut.clk.value = 0
    await Timer(5, unit='ns')
    dut.rst_n.value = 0
    await Timer(5, unit='ns')
    check(dut, 1, 0, 'reset must wait for rising edge')
    dut.clk.value = 1
    await Timer(5, unit='ns')
    check(dut, 0, 1, 'reset overrides send and aborts')
    await Timer(5, unit='ns')
    await tick(dut)
    check(dut, 0, 1, 'held reset overrides held send')
    dut.send.value = 0
    dut.rst_n.value = 1
    for age in range(45):
        await tick(dut)
        check(dut, 0, 1, f'aborted frame never resumes {age}')
    dut.clk.value = 0
    await Timer(5, unit='ns')
    dut.rst_n.value = 0
    await Timer(5, unit='ns')
    check(dut, 0, 1, 'idle between-edge reset')
    dut.send.value = 1
    dut.clk.value = 1
    await Timer(5, unit='ns')
    check(dut, 0, 1, 'idle reset priority')
    await Timer(5, unit='ns')
    dut.rst_n.value = 1
    await tick(dut)
    check(dut, 1, 0, 'new request after reset release')


@cocotb.test()
async def edge_payloads_full_stop_and_sustained_idle(dut):
    await reset(dut)
    for payload in (0x00, 0xff):
        await frame(dut, payload)
        for age in range(12):
            dut.data.value = (age * 37) & 255
            await tick(dut)
            check(dut, 0, 1, f'sustained idle {age}')
