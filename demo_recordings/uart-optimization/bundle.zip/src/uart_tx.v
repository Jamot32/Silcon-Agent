module uart_tx #(
    parameter integer BAUD_DIV = 16
) (
    input wire clk,
    input wire rst_n,
    input wire [7:0] data_in,
    input wire start,
    output wire tx,
    output reg busy
);
    localparam integer COUNT_WIDTH = (BAUD_DIV > 1) ? $clog2(BAUD_DIV) : 1;
    localparam [31:0] DIV_LAST = BAUD_DIV - 1;

    reg [COUNT_WIDTH-1:0] baud_count;
    reg [3:0] bit_index;
    reg [9:0] frame;

    assign tx = frame[0];

    always @(posedge clk) begin
        if (!rst_n) begin
            frame <= 10'b1111111111;
            busy <= 1'b0;
            baud_count <= {COUNT_WIDTH{1'b0}};
            bit_index <= 4'd0;
        end else if (!busy) begin
            frame <= 10'b1111111111;
            baud_count <= {COUNT_WIDTH{1'b0}};
            bit_index <= 4'd0;
            busy <= 1'b0;
            if (start) begin
                frame <= {1'b1, data_in, 1'b0};
                busy <= 1'b1;
            end
        end else if (baud_count == DIV_LAST[COUNT_WIDTH-1:0]) begin
            baud_count <= {COUNT_WIDTH{1'b0}};
            frame <= {1'b1, frame[9:1]};
            if (bit_index == 4'd9) begin
                busy <= 1'b0;
                bit_index <= 4'd0;
            end else begin
                bit_index <= bit_index + 4'd1;
            end
        end else begin
            baud_count <= baud_count + {{(COUNT_WIDTH-1){1'b0}}, 1'b1};
        end
    end
endmodule
