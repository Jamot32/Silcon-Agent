import cocotb
from cocotb.triggers import Timer


DIV = 16


async def tick(dut):
    dut.clk.value = 0
    await Timer(5, unit='ns')
    dut.clk.value = 1
    await Timer(5, unit='ns')


def check(dut, tx, busy, label):
    assert int(dut.tx.value) == tx, label + ': tx'
    assert int(dut.busy.value) == busy, label + ': busy'


async def reset(dut):
    dut.clk.value = 0
    dut.rst_n.value = 0
    dut.start.value = 0
    dut.data_in.value = 0
    await tick(dut)
    check(dut, 1, 0, 'reset')
    dut.rst_n.value = 1


async def accept(dut, value):
    dut.data_in.value = value
    dut.start.value = 1
    await tick(dut)
    check(dut, 0, 1, 'acceptance')
    dut.start.value = 0


async def frame(dut, value, disturb=False, held=False):
    bits = [0] + [(value >> n) & 1 for n in range(8)] + [1]
    check(dut, 0, 1, 'frame interval 0')
    for elapsed in range(1, 10 * DIV + 1):
        if disturb:
            dut.data_in.value = (elapsed * 37) & 255
            dut.start.value = int(elapsed % 3 == 0 or elapsed == 10 * DIV)
        elif held:
            dut.start.value = 1
        await tick(dut)
        if elapsed == 10 * DIV:
            check(dut, 1, 0, 'exact completion')
        else:
            check(dut, bits[elapsed // DIV], 1, 'interval ' + str(elapsed))


async def idle(dut, count=5):
    dut.start.value = 0
    for n in range(count):
        await tick(dut)
        check(dut, 1, 0, 'idle ' + str(n))


@cocotb.test()
async def default_divider_a5_exact_intervals(dut):
    await reset(dut)
    await accept(dut, 0xA5)
    await frame(dut, 0xA5)
    await idle(dut)


@cocotb.test()
async def equal_bit_runs_and_idle(dut):
    await reset(dut)
    for value in [0x00, 0xFF, 0x55, 0x80]:
        await accept(dut, value)
        await frame(dut, value)
        await idle(dut)


@cocotb.test()
async def busy_requests_ignored_including_completion(dut):
    await reset(dut)
    await accept(dut, 0x96)
    await frame(dut, 0x96, disturb=True)
    await idle(dut, 10 * DIV + 3)


@cocotb.test()
async def held_start_recaptures_after_completion(dut):
    await reset(dut)
    await accept(dut, 0x3C)
    dut.data_in.value = 0xC3
    await frame(dut, 0x3C, held=True)
    # Completion leaves one full idle interval before the next acceptance.
    dut.clk.value = 0
    await Timer(5, unit='ns')
    check(dut, 1, 0, 'between completion and reacceptance')
    dut.data_in.value = 0x69
    await tick(dut)
    check(dut, 0, 1, 'held start reaccepted next edge')
    dut.start.value = 0
    await frame(dut, 0x69)
    await idle(dut)


@cocotb.test()
async def synchronous_idle_reset_priority(dut):
    await reset(dut)
    dut.clk.value = 0
    dut.start.value = 1
    dut.data_in.value = 0
    dut.rst_n.value = 0
    await Timer(5, unit='ns')
    check(dut, 1, 0, 'idle before reset edge')
    await tick(dut)
    check(dut, 1, 0, 'reset overrides start')
    dut.rst_n.value = 1
    await Timer(5, unit='ns')
    check(dut, 1, 0, 'reset release between edges')
    await tick(dut)
    check(dut, 0, 1, 'accept after reset release')
    dut.start.value = 0
    await frame(dut, 0)


@cocotb.test()
async def synchronous_abort_and_recovery(dut):
    await reset(dut)
    for offset in [0, DIV + 3, 5 * DIV + 1, 9 * DIV + 2]:
        await accept(dut, 0xA5)
        for n in range(offset):
            await tick(dut)
        old_tx = int(dut.tx.value)
        check(dut, old_tx, 1, 'before abort')
        dut.clk.value = 0
        dut.rst_n.value = 0
        dut.start.value = 1
        await Timer(5, unit='ns')
        check(dut, old_tx, 1, 'reset must wait for rising edge')
        await tick(dut)
        check(dut, 1, 0, 'abort edge overrides start')
        dut.start.value = 0
        dut.rst_n.value = 1
        await idle(dut, 3)
        await accept(dut, 0x5A)
        await frame(dut, 0x5A)
        await idle(dut)
